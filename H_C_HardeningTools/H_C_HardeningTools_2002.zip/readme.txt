H_C Hardening Tools (Hard_Configurator Hardening Tools).

These tools contain some tools used in Hard_Configurator.

ConfigureDefender - can activate many advanced Windows Defender settings.

DocumentsAntiExploit - can be used to block macros and harden MS Office applications.

FirewallHardening - can be used to block Windows Firewall outbound connections of many LOLBins and other executables chosen by the user. Please use "External BlockList" <Load> option to update the predefined BlockList entries (they are included in the file UpdateFirewallHardening2011.fwbl)

RunBySmartScreen - can be used to safely run/open files.

------------------------------------------------------------------------------------------
Disclaimer of Warranty
THIS SOFTWARE IS DISTRIBUTED "AS IS". NO WARRANTY OF ANY KIND IS EXPRESSED OR IMPLIED. YOU USE IT AT YOUR OWN RISK. THE AUTHOR WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING THIS SOFTWARE.

Distribution
These tools may be freely distributed as long as no modification is made to it. 

Andrzej Pluta (@Andy Ful)