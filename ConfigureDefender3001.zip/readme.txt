INFO ABOUT EXECUTABLES

The executable ConfigureDefender.exe contains executables for Windows 64-bit and 32-bit (wrapped by NSISS).

Please run the NotificationAreaReset.exe to clear the cache if the taskbar notification area cache contains too many unused entries. This can happen for many applications that put icons into the notification area. This was also a case for ConfigureDefender (standalone version 3.0.0.0). From version 3.0.0.1, ConfigureDefender does not use notification area anymore.

------------------------------------------------------------------------------------------
CONFIGUREDEFENDER DISCLAIMER OF WARRANTY

THIS SOFTWARE IS DISTRIBUTED "AS IS". NO WARRANTY OF ANY KIND IS EXPRESSED OR IMPLIED. YOU USE IT AT YOUR OWN RISK. THE AUTHOR WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING THIS SOFTWARE.

Distribution
ConfigureDefender may be freely distributed as long as no modification is made to it. 

Andrzej Pluta (@Andy Ful)